<?php

declare(strict_types=1);

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Services\Storefront\CategoryShelf;
use App\Services\Storefront\HomepageBuilder;
use App\Services\Storefront\PublicCatalog;
use App\Support\StorefrontHomepageMode;
use Illuminate\Http\Response;

/** Keep / unchanged while switching between the published homepage and the default landing. */
final class RootHomepageController extends Controller
{
    public function __invoke(
        StorefrontHomepageMode $mode,
        HomeController $campaignHome,
        StorefrontCatalogController $storefrontHome,
        PublicCatalog $catalog,
        HomepageBuilder $builder,
        CategoryShelf $shelves,
    ): Response {
        if ($mode->current() === StorefrontHomepageMode::CAMPAIGN) {
            // Same active-default selection + latest-active fallback as the legacy root page.
            return $campaignHome->index();
        }

        // Keep the existing storefront renderer, guards and published-only policy.
        return $storefrontHome->home($catalog, $builder, $shelves);
    }
}
