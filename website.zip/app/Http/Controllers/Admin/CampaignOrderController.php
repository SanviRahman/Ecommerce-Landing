<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Campaign;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ShippingCharge;
use App\Services\CustomerIdentityService;
use App\Services\OrderAssignmentService;
use App\Services\OrderBlockService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CampaignOrderController extends Controller
{
    /**
     * Keep customer phone as exactly 11 local digits.
     * Example accepted format: 01XXXXXXXXX.
     * Country prefix like +88/88 is intentionally rejected by local BD phone validation.
     */
    private function normalizeCustomerPhone(?string $phone): string
    {
        return preg_replace('/\D+/', '', (string) $phone) ?: '';
    }

    private function normalizeProductImagePath(?string $value): ?string
    {
        if (! $value) {
            return null;
        }

        $value = trim($value);

        if ($value === '') {
            return null;
        }

        if (filter_var($value, FILTER_VALIDATE_URL) || str_starts_with($value, 'data:') || str_starts_with($value, '//')) {
            return $value;
        }

        $value = ltrim($value, '/');

        if (str_starts_with($value, 'public/')) {
            return Storage::url(substr($value, 7));
        }

        if (str_starts_with($value, 'storage/app/public/')) {
            return Storage::url(substr($value, 19));
        }

        if (str_starts_with($value, 'storage/')) {
            return asset($value);
        }

        return Storage::url($value);
    }

    private function resolveProductImageUrl(?Product $product): ?string
    {
        if (! $product) {
            return null;
        }

        foreach ([
            'image_url',
            'thumbnail_url',
            'photo_url',
            'product_image_url',
            'image',
            'photo',
            'thumbnail',
            'thumb',
            'product_image',
            'product_photo',
            'main_image',
            'featured_image',
            'featured_photo',
            'image_path',
            'photo_path',
            'thumbnail_path',
            'picture',
        ] as $attribute) {
            try {
                $value = $product->{$attribute} ?? null;
            } catch (\Throwable $e) {
                $value = null;
            }

            if (is_array($value)) {
                $value = collect($value)->filter()->first();
            }

            if (is_string($value) && str_starts_with(trim($value), '[')) {
                $decoded = json_decode($value, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $value = collect($decoded)->filter()->first();
                }
            }

            if ($url = $this->normalizeProductImagePath(is_string($value) ? $value : null)) {
                return $url;
            }
        }

        if (method_exists($product, 'getFirstMediaUrl')) {
            foreach ([
                'product_image',
                'product_images',
                'product_thumbnail',
                'product_photo',
                'product_gallery',
                'product',
                'products',
                'image',
                'images',
                'photo',
                'photos',
                'thumbnail',
                'thumb',
                'gallery',
                'main_image',
                'featured_image',
                'default',
            ] as $collection) {
                try {
                    $url = $product->getFirstMediaUrl($collection);

                    if ($url) {
                        return $url;
                    }
                } catch (\Throwable $e) {
                    // Continue checking other media collections.
                }
            }

            try {
                $url = $product->getFirstMediaUrl();

                if ($url) {
                    return $url;
                }
            } catch (\Throwable $e) {
                // No default media collection available.
            }
        }

        return null;
    }

    public function store(
        Request $request,
        Campaign $campaign,
        CustomerIdentityService $customerIdentityService,
        OrderBlockService $orderBlockService
    ) {
        // A canonical /campaign/{slug}/order works for standard and custom-route campaigns.
        return $this->storeCampaignOrder(
            $request,
            $campaign,
            $customerIdentityService,
            $orderBlockService
        );
    }

    public function storeByCustomRoute(
        Request $request,
        string $customRoute,
        CustomerIdentityService $customerIdentityService,
        OrderBlockService $orderBlockService
    ) {
        $campaign = Campaign::query()
            ->where('route_type', Campaign::ROUTE_CUSTOM)
            ->where('custom_route', strtolower($customRoute))
            ->firstOrFail();

        return $this->storeCampaignOrder(
            $request,
            $campaign,
            $customerIdentityService,
            $orderBlockService
        );
    }

    private function storeCampaignOrder(
        Request $request,
        Campaign $campaign,
        CustomerIdentityService $customerIdentityService,
        OrderBlockService $orderBlockService
    ) {
        abort_if(! $campaign->status, 404);

        $request->merge([
            'phone' => $this->normalizeCustomerPhone($request->input('phone')),
        ]);

        $request->validate([
            'customer_name'       => ['required', 'string', 'max:255'],
            'phone'               => ['required', 'string', 'regex:/^01[0-9]{9}$/'],
            'address'             => ['required', 'string'],
            'delivery_area'       => ['nullable', 'string', 'max:255'],
            'customer_note'       => ['nullable', 'string', 'max:1000'],
            'order_form_token'    => ['required', 'string', 'max:100'],
            'device_identifier'   => ['nullable', 'string', 'min:16', 'max:100', 'regex:/^[A-Za-z0-9_-]+$/'],

            'products'            => ['required', 'array', 'min:1'],
            'products.*.id'       => ['required', 'integer', 'exists:products,id'],
            'products.*.quantity' => ['required', 'integer', 'min:1', 'max:1000'],
        ]);

        $activeBlock = $orderBlockService->findActiveBlock(
            $request->input('phone'),
            $request->ip()
        );

        if ($activeBlock) {
            return back()
                ->withInput($request->except(['products', 'order_form_token']))
                ->with(
                    'blocked_order_error',
                    'আপনি অর্ডার করতে পারবেন না। সহায়তার জন্য আমাদের সঙ্গে যোগাযোগ করুন।'
                );
        }

        // Resolve products and shipping before touching customer records or consuming
        // the one-time form token. Failed validation must not create partial orders.
        return DB::transaction(function () use ($request, $campaign, $customerIdentityService) {
            app(\App\Services\Inventory\ManagedOrderWriter::class)->assertTransactionReady();
            $campaign->load([
                'products' => function ($query) {
                    $query->where('products.status', true);
                },
            ]);

            $campaignProducts = $campaign->products->keyBy('id');

            $submittedProducts = collect($request->products)
                ->groupBy('id')
                ->map(function ($items) {
                    return [
                        'id'       => (int) $items->first()['id'],
                        'quantity' => (int) $items->sum('quantity'),
                    ];
                })
                ->values();

            $subTotal = 0;
            $orderItems = [];

            foreach ($submittedProducts as $submittedProduct) {
                $productId = (int) $submittedProduct['id'];
                $product = $campaignProducts->get($productId);

                // A campaign checkout may never include a globally active product
                // that is not explicitly attached to this campaign.
                if (! $product) {
                    throw ValidationException::withMessages([
                        'products' => 'One or more selected products are not available in this campaign.',
                    ]);
                }

                $quantity = (int) $submittedProduct['quantity'];
                if ($quantity < 1 || $quantity > 1000) {
                    throw ValidationException::withMessages([
                        'products' => 'Please select a valid quantity (1-1000) for each product.',
                    ]);
                }
                $campaignPrice = isset($product->pivot) ? (int) ($product->pivot->campaign_price ?? 0) : 0;
                $unitPrice = $campaignPrice > 0 ? $campaignPrice : (int) $product->new_price;

                if ($unitPrice <= 0) {
                    throw ValidationException::withMessages([
                        'products' => 'A selected campaign product has no valid price.',
                    ]);
                }

                $lineTotal = $unitPrice * $quantity;
                $subTotal += $lineTotal;

                $orderItems[] = [
                    'product'          => $product,
                    'quantity'         => $quantity,
                    'unit_price'       => $unitPrice,
                    'line_total'       => $lineTotal,
                    'is_free_delivery' => (bool) ($product->is_free_delivery ?? false),
                ];
            }

            if (empty($orderItems)) {
                throw ValidationException::withMessages([
                    'products' => 'Please select at least one valid campaign product.',
                ]);
            }

            $hasAnyFreeDeliveryProduct = collect($orderItems)
                ->contains(fn ($item) => (bool) $item['is_free_delivery']);

            $selectedShippingCharge = null;

            if (! $hasAnyFreeDeliveryProduct) {
                $availableShippingCharges = ShippingCharge::resolvedForCampaign($campaign->id);

                $selectedShippingCharge = $availableShippingCharges
                    ->first(fn (ShippingCharge $charge) => (string) $charge->id === (string) $request->delivery_area);

                if (! $selectedShippingCharge) {
                    throw ValidationException::withMessages([
                        'delivery_area' => 'Please select a valid delivery area.',
                    ]);
                }

                $shippingCharge = (int) $selectedShippingCharge->delivery_charge;
                $deliveryAreaName = $selectedShippingCharge->area_name;
            } else {
                $shippingCharge = 0;
                $deliveryAreaName = 'free_delivery';
            }

            $codCharge = 0;
            $totalAmount = $subTotal + $shippingCharge + $codCharge;

            if (! $this->consumeOrderFormToken($request->input('order_form_token'))) {
                return back()
                    ->withInput($request->except(['products', 'order_form_token']))
                    ->with('error', 'এই পুরোনো ফর্ম দিয়ে আবার অর্ডার করা যাবে না। অনুগ্রহ করে পেজ refresh করে নতুন করে অর্ডার করুন।');
            }

            $customer = $customerIdentityService->resolveOrCreate(
                $request->customer_name,
                $request->phone,
                'phone'
            );

            $order = Order::create([
                'invoice_id'        => $this->generateInvoiceId(),
                'success_token'     => Str::random(40),
                'campaign_id'       => $campaign->id,
                'customer_id'       => $customer->id,

                'customer_name'     => $customer->name,
                'phone'             => $customer->phone,
                'address'           => $request->address,
                'delivery_area'     => $deliveryAreaName,

                'courier_service'    => null,
                'courier_account_id' => null,
                'courier_id'         => null,

                'sub_total'         => $subTotal,
                'shipping_charge'   => $shippingCharge,
                'is_free_delivery'  => $hasAnyFreeDeliveryProduct,
                'cod_charge'        => $codCharge,
                'total_amount'      => $totalAmount,

                'payment_method'    => Order::PAYMENT_COD,
                'payment_status'    => Order::PAYMENT_STATUS_COD_PENDING,

                // New customer order will be listed in both All Orders and New Orders.
                // New Orders means Processing status according to your requirement.
                'order_status'      => Order::STATUS_PROCESSING,

                'is_fake'           => false,
                'customer_note'     => $request->customer_note,

                // Keep the public/network IP for auditing/blocking only.
                // Duplicate-order highlighting uses the browser-scoped device identifier instead.
                'source_ip'         => $request->ip(),
                'device_identifier' => $request->filled('device_identifier')
                    ? trim((string) $request->input('device_identifier'))
                    : null,
                'user_agent'        => $request->userAgent(),
                'source_url'        => url()->previous(),
            ]);

            foreach ($orderItems as $item) {
                OrderItem::create([
                    'order_id'     => $order->id,
                    'product_id'   => $item['product']->id,
                    'product_name' => $item['product']->name,
                    'unit_price'   => $item['unit_price'],
                    'quantity'     => $item['quantity'],
                    'total_price'  => $item['line_total'],
                ]);
            }

            app(\App\Services\Inventory\ManagedOrderWriter::class)->allocateCreatedOrder($order->id, 'products');

            app(OrderAssignmentService::class)->assign($order);

            return redirect()
                ->route('order.success', $order->success_token)
                ->with('success', 'আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে। খুব শীঘ্রই আমাদের প্রতিনিধি যোগাযোগ করবে।');
        });
    }

    private function consumeOrderFormToken(?string $token): bool
    {
        if (! $token) {
            return false;
        }

        $tokens = session()->get('campaign_order_form_tokens', []);

        if (! is_array($tokens) || ! in_array($token, $tokens, true)) {
            return false;
        }

        $tokens = array_values(array_filter($tokens, fn ($storedToken) => $storedToken !== $token));

        session()->put('campaign_order_form_tokens', $tokens);

        return true;
    }

    private function generateInvoiceId(): string
    {
        do {
            $invoiceId = 'INV-' . now()->format('Ymd') . '-' . strtoupper(Str::random(6));
        } while (Order::where('invoice_id', $invoiceId)->exists());

        return $invoiceId;
    }
}
