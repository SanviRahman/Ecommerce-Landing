<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class BannerController extends Controller
{
    /**
     * Check if the user is an admin.
     */
    private function adminOnly(): void
    {
        if (! auth()->user()->isAdmin()) {
            abort(403, 'Unauthorized access.');
        }
    }

    /**
     * Base query for banners.
     */
    private function bannerQuery(bool $trash = false): Builder
    {
        $query = $trash ? Banner::onlyTrashed() : Banner::query();
        return $query->latest();
    }

    /**
     * Apply Search and Filters.
     */
    private function applyFilters(Builder $query, Request $request): Builder
    {
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('position', 'like', "%{$search}%")
                  ->orWhere('link', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', (bool) $request->status);
        }

        if ($request->filled('position') && $request->position !== 'all') {
            $query->where('position', $request->position);
        }

        return $query;
    }

    /**
     * Reusable list response for Index & Trash.
     */
    private function listResponse(Request $request, Builder $query, string $title, bool $isTrash = false)
    {
        $query = $this->applyFilters($query, $request);
        $banners = $query->paginate(15);

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Banners', 'url' => route('admin.banners.index')],
        ];

        if ($isTrash) {
            $breadcrumb[] = [
                'text' => 'Trash',
                'url' => route('admin.banners.trashed'),
            ];
        }

        if ($request->ajax()) {
            return response()->json([
                'status' => true,
                'html' => view('admin.banners.partials.table', [
                    'banners' => $banners,
                    'isTrash' => $isTrash,
                ])->render(),
            ]);
        }

        return view('admin.banners.index', [
            'banners' => $banners,
            'title' => $title,
            'breadcrumb' => $breadcrumb,
            'isTrash' => $isTrash,
        ]);
    }

    public function index(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->bannerQuery(), 'All Banners');
    }

    public function trash(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->bannerQuery(true), 'Trashed Banners', true);
    }

    public function create(Request $request)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.banners.index');
        }

        $banner = null;
        $isEdit = false;
        $action = route('admin.banners.store');

        return response()->json([
            'status' => true,
            'html' => view('admin.banners.partials.form', compact('banner', 'isEdit', 'action'))->render(),
        ]);
    }

    public function store(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'position' => ['required', 'string', Rule::in(['hero', 'middle', 'footer', 'popup', 'review', 'help'])],
            'link' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'status' => ['nullable', 'boolean'],
            'banner_image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'], // Image should be required for a new banner
        ]);

        DB::transaction(function () use ($request) {
            $banner = Banner::create([
                'title' => $request->title,
                'position' => $request->position,
                'link' => $request->link,
                'sort_order' => $request->sort_order ?? 0,
                'status' => $request->has('status') ? true : false,
            ]);

            if ($request->hasFile('banner_image')) {
                $banner->addMediaFromRequest('banner_image')->toMediaCollection('banner_image');
            }
        });

        return response()->json([
            'status' => true,
            'message' => 'Banner created successfully.',
        ]);
    }

    public function show(Request $request, Banner $banner)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.banners.index');
        }

        return response()->json([
            'status' => true,
            'html' => view('admin.banners.partials.show', compact('banner'))->render(),
        ]);
    }

    public function edit(Request $request, Banner $banner)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.banners.index');
        }

        $isEdit = true;
        $action = route('admin.banners.update', $banner->id);

        return response()->json([
            'status' => true,
            'html' => view('admin.banners.partials.form', compact('banner', 'isEdit', 'action'))->render(),
        ]);
    }

    public function update(Request $request, Banner $banner)
    {
        $this->adminOnly();

        $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'position' => ['required', 'string', Rule::in(['hero', 'middle', 'footer', 'popup', 'review', 'help'])],
            'link' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'banner_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        DB::transaction(function () use ($request, $banner) {
            $banner->update([
                'title' => $request->title,
                'position' => $request->position,
                'link' => $request->link,
                'sort_order' => $request->sort_order ?? 0,
                'status' => $request->has('status'),
            ]);

            if ($request->hasFile('banner_image')) {
                $banner->clearMediaCollection('banner_image');
                $banner->addMediaFromRequest('banner_image')->toMediaCollection('banner_image');
            }
        });

        return response()->json([
            'status' => true,
            'message' => 'Banner updated successfully.',
        ]);
    }

    public function destroy(Banner $banner)
    {
        $this->adminOnly();
        $banner->delete();

        return response()->json([
            'status' => true,
            'message' => 'Banner moved to trash successfully.',
        ]);
    }

    public function restore($id)
    {
        $this->adminOnly();
        Banner::onlyTrashed()->findOrFail($id)->restore();

        return response()->json([
            'status' => true,
            'message' => 'Banner restored successfully.',
        ]);
    }

    public function forceDelete($id)
    {
        $this->adminOnly();
        $banner = Banner::onlyTrashed()->findOrFail($id);
        
        $banner->clearMediaCollection('banner_image');
        $banner->forceDelete();

        return response()->json([
            'status' => true,
            'message' => 'Banner permanently deleted.',
        ]);
    }

    public function multipleAction(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'action' => ['required', 'in:delete,restore,force_delete,active,inactive'],
            'ids' => ['required', 'array'],
            'ids.*' => ['integer'],
        ]);

        $ids = $request->ids;
        $action = $request->action;

        if ($action === 'delete') {
            Banner::whereIn('id', $ids)->delete();
            return response()->json(['status' => true, 'message' => 'Selected banners moved to trash.']);
        }

        if ($action === 'restore') {
            Banner::onlyTrashed()->whereIn('id', $ids)->restore();
            return response()->json(['status' => true, 'message' => 'Selected banners restored.']);
        }

        if ($action === 'force_delete') {
            $banners = Banner::onlyTrashed()->whereIn('id', $ids)->get();
            foreach ($banners as $banner) {
                $banner->clearMediaCollection('banner_image');
                $banner->forceDelete();
            }
            return response()->json(['status' => true, 'message' => 'Selected banners permanently deleted.']);
        }

        $status = $action === 'active' ? true : false;
        Banner::whereIn('id', $ids)->update(['status' => $status]);

        return response()->json([
            'status' => true,
            'message' => 'Selected banners status updated.',
        ]);
    }

    public function deleteMedia($id)
    {
        $this->adminOnly();
        
        $media = Media::findOrFail($id);
        $media->delete();

        return response()->json([
            'status' => true,
            'message' => 'Banner image deleted successfully.',
        ]);
    }
}