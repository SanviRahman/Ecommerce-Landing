<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CreatePage;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CreatePageController extends Controller
{
    /**
     * Check if the user is an admin.
     */
    private function adminOnly(): void
    {
        if (! auth()->user()->isAdmin()) {
            abort(403, 'Unauthorized access.');
        }
    }

    /**
     * Base query for pages.
     */
    private function pageQuery(bool $trash = false): Builder
    {
        $query = $trash ? CreatePage::onlyTrashed() : CreatePage::query();
        return $query->latest();
    }

    /**
     * Apply Search and Filters.
     */
    private function applyFilters(Builder $query, Request $request): Builder
    {
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('page_name', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%")
                  ->orWhere('meta_title', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', (bool) $request->status);
        }

        return $query;
    }

    /**
     * Reusable list response for Index & Trash.
     */
    private function listResponse(Request $request, Builder $query, string $title, bool $isTrash = false)
    {
        $query = $this->applyFilters($query, $request);
        $pages = $query->paginate(15);

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Pages', 'url' => route('admin.pages.index')],
        ];

        if ($isTrash) {
            $breadcrumb[] = [
                'text' => 'Trash',
                'url' => route('admin.pages.trashed'),
            ];
        }

        if ($request->ajax()) {
            return response()->json([
                'status' => true,
                'html' => view('admin.pages.partials.table', [
                    'pages' => $pages,
                    'isTrash' => $isTrash,
                ])->render(),
            ]);
        }

        return view('admin.pages.index', [
            'pages' => $pages,
            'title' => $title,
            'breadcrumb' => $breadcrumb,
            'isTrash' => $isTrash,
        ]);
    }

    public function index(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->pageQuery(), 'All Pages');
    }

    public function trash(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->pageQuery(true), 'Trashed Pages', true);
    }

    public function create()
    {
        $this->adminOnly();

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Pages', 'url' => route('admin.pages.index')],
            ['text' => 'Create Page', 'url' => route('admin.pages.create')],
        ];

        return view('admin.pages.create', [
            'title' => 'Create New Page',
            'breadcrumb' => $breadcrumb,
        ]);
    }

    public function store(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'page_name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:255', 'unique:create_pages,slug'],
            'description' => ['nullable', 'string'],
            'meta_title' => ['nullable', 'string', 'max:255'],
            'meta_description' => ['nullable', 'string'],
            'banner_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        DB::transaction(function () use ($request) {
            $slug = Str::slug($request->slug ?? $request->page_name);
            
            // Ensure slug uniqueness fallback
            if (CreatePage::where('slug', $slug)->exists()) {
                $slug = $slug . '-' . time();
            }

            $page = CreatePage::create([
                'page_name' => $request->page_name,
                'slug' => $slug,
                'description' => $request->description,
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'status' => $request->has('status') ? true : false,
            ]);

            if ($request->hasFile('banner_image')) {
                $page->addMediaFromRequest('banner_image')->toMediaCollection('page_banner');
            }
        });

        return redirect()->route('admin.pages.index')->with('success', 'Page created successfully.');
    }

    public function show(CreatePage $page)
    {
        $this->adminOnly();

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Pages', 'url' => route('admin.pages.index')],
            ['text' => 'Page Details', 'url' => route('admin.pages.show', $page->id)],
        ];

        return view('admin.pages.show', compact('page', 'breadcrumb'));
    }

    public function edit(CreatePage $page)
    {
        $this->adminOnly();

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Pages', 'url' => route('admin.pages.index')],
            ['text' => 'Edit Page', 'url' => route('admin.pages.edit', $page->id)],
        ];

        return view('admin.pages.edit', [
            'page' => $page,
            'title' => 'Edit Page',
            'breadcrumb' => $breadcrumb,
        ]);
    }

    public function update(Request $request, CreatePage $page)
    {
        $this->adminOnly();

        $request->validate([
            'page_name' => ['required', 'string', 'max:255'],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('create_pages', 'slug')->ignore($page->id),
            ],
            'description' => ['nullable', 'string'],
            'meta_title' => ['nullable', 'string', 'max:255'],
            'meta_description' => ['nullable', 'string'],
            'banner_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        DB::transaction(function () use ($request, $page) {
            $slug = Str::slug($request->slug ?? $request->page_name);
            
            if (CreatePage::where('slug', $slug)->where('id', '!=', $page->id)->exists()) {
                $slug = $slug . '-' . time();
            }

            $page->update([
                'page_name' => $request->page_name,
                'slug' => $slug,
                'description' => $request->description,
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'status' => $request->has('status'),
            ]);

            if ($request->hasFile('banner_image')) {
                $page->clearMediaCollection('page_banner');
                $page->addMediaFromRequest('banner_image')->toMediaCollection('page_banner');
            }
        });

        return redirect()->route('admin.pages.index')->with('success', 'Page updated successfully.');
    }

    public function destroy(CreatePage $page)
    {
        $this->adminOnly();
        $page->delete();

        return response()->json([
            'status' => true,
            'message' => 'Page moved to trash successfully.',
        ]);
    }

    public function restore($id)
    {
        $this->adminOnly();
        CreatePage::onlyTrashed()->findOrFail($id)->restore();

        return response()->json([
            'status' => true,
            'message' => 'Page restored successfully.',
        ]);
    }

    public function forceDelete($id)
    {
        $this->adminOnly();
        $page = CreatePage::onlyTrashed()->findOrFail($id);
        
        $page->clearMediaCollection('page_banner');
        $page->forceDelete();

        return response()->json([
            'status' => true,
            'message' => 'Page permanently deleted.',
        ]);
    }

    public function multipleAction(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'action' => ['required', 'in:delete,restore,force_delete,active,inactive'],
            'ids' => ['required', 'array'],
            'ids.*' => ['integer'],
        ]);

        $ids = $request->ids;
        $action = $request->action;

        if ($action === 'delete') {
            CreatePage::whereIn('id', $ids)->delete();
            return response()->json(['status' => true, 'message' => 'Selected pages moved to trash.']);
        }

        if ($action === 'restore') {
            CreatePage::onlyTrashed()->whereIn('id', $ids)->restore();
            return response()->json(['status' => true, 'message' => 'Selected pages restored.']);
        }

        if ($action === 'force_delete') {
            $pages = CreatePage::onlyTrashed()->whereIn('id', $ids)->get();
            foreach ($pages as $page) {
                $page->clearMediaCollection('page_banner');
                $page->forceDelete();
            }
            return response()->json(['status' => true, 'message' => 'Selected pages permanently deleted.']);
        }

        $status = $action === 'active' ? true : false;
        CreatePage::whereIn('id', $ids)->update(['status' => $status]);

        return response()->json([
            'status' => true,
            'message' => 'Selected pages status updated.',
        ]);
    }

    public function deleteMedia($id)
    {
        $this->adminOnly();
        
        $media = Media::findOrFail($id);
        $media->delete();

        return response()->json([
            'status' => true,
            'message' => 'Page banner deleted successfully.',
        ]);
    }
}