<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BulkOrder;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BulkOrderController extends Controller
{
    /**
     * Reusable query for bulk orders with eager loading.
     */
    private function bulkOrderQuery(bool $trash = false): Builder
    {
        $query = $trash ? BulkOrder::onlyTrashed() : BulkOrder::query();

        return $query->with(['campaign'])->latest();
    }

    /**
     * Apply Search and Filters.
     */
    private function applyFilters(Builder $query, Request $request): Builder
    {
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('customer_name', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('company_name', 'like', "%{$search}%")
                    ->orWhere('product_name', 'like', "%{$search}%")
                    ->orWhere('id', $search);
            });
        }

        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        return $query;
    }

    /**
     * Reusable list response for different statuses.
     */
    private function listResponse(Request $request, Builder $query, string $title, string $currentRoute, bool $isTrash = false)
    {
        $query      = $this->applyFilters($query, $request);
        $bulkOrders = $query->paginate(15);

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Bulk Orders', 'url' => route('admin.bulk-orders.index')],
            ['text' => $title, 'url' => route($currentRoute)],
        ];

        $viewType = str_replace('admin.bulk-orders.', '', $currentRoute);

        if ($request->ajax()) {
            return response()->json([
                'status' => true,
                'html'   => view('admin.bulk-orders.partials.table', [
                    'bulkOrders' => $bulkOrders,
                    'viewType'   => $viewType,
                    'isTrash'    => $isTrash,
                ])->render(),
            ]);
        }

        return view('admin.bulk-orders.index', [
            'bulkOrders' => $bulkOrders,
            'title'      => $title,
            'breadcrumb' => $breadcrumb,
            'viewType'   => $viewType,
            'isTrash'    => $isTrash,
        ]);
    }

    public function index(Request $request)
    {
        return $this->listResponse(
            $request,
            $this->bulkOrderQuery(),
            'All Bulk Orders',
            'admin.bulk-orders.index'
        );
    }

    public function newRequests(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery()->new(), 'New Bulk Requests', 'admin.bulk-orders.new');
    }

    public function contacted(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery()->contacted(), 'Contacted Requests', 'admin.bulk-orders.contacted');
    }

    public function quoted(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery()->quoted(), 'Quoted Requests', 'admin.bulk-orders.quoted');
    }

    public function confirmed(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery()->confirmed(), 'Confirmed Bulk Orders', 'admin.bulk-orders.confirmed');
    }

    public function cancelled(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery()->cancelled(), 'Cancelled Requests', 'admin.bulk-orders.cancelled');
    }

    public function show(BulkOrder $bulkOrder)
    {
        $bulkOrder->load('campaign');

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'Bulk Orders', 'url' => route('admin.bulk-orders.index')],
            ['text' => 'Bulk Order Details', 'url' => route('admin.bulk-orders.show', $bulkOrder->id)],
        ];

        return view('admin.bulk-orders.show', compact('bulkOrder', 'breadcrumb'));
    }

    public function updateStatus(Request $request, BulkOrder $bulkOrder)
    {
        $request->validate([
            'status'     => [
                'required',
                Rule::in([
                    BulkOrder::STATUS_NEW,
                    BulkOrder::STATUS_CONTACTED,
                    BulkOrder::STATUS_QUOTED,
                    BulkOrder::STATUS_CONFIRMED,
                    BulkOrder::STATUS_CANCELLED,
                ]),
            ],
            'admin_note' => ['nullable', 'string'],
        ]);

        $bulkOrder->status = $request->status;

        if ($request->filled('admin_note')) {
            $bulkOrder->admin_note = $request->admin_note;
        }

        $bulkOrder->save();

        return response()->json([
            'status'  => true,
            'message' => 'Bulk order status updated successfully.',
        ]);
    }

    public function destroy(BulkOrder $bulkOrder)
    {
        $bulkOrder->delete();

        return response()->json([
            'status'  => true,
            'message' => 'Bulk order moved to trash successfully.',
        ]);
    }

    // --- New Methods for Trash & Bulk Actions ---

    public function trash(Request $request)
    {
        return $this->listResponse($request, $this->bulkOrderQuery(true), 'Trash Bin', 'admin.bulk-orders.trashed', true);
    }

    public function restore($id)
    {
        BulkOrder::onlyTrashed()->findOrFail($id)->restore();

        return response()->json([
            'status'  => true,
            'message' => 'Bulk order restored successfully.',
        ]);
    }

    public function forceDelete($id)
    {
        BulkOrder::onlyTrashed()->findOrFail($id)->forceDelete();

        return response()->json([
            'status'  => true,
            'message' => 'Bulk order permanently deleted.',
        ]);
    }

    public function multipleAction(Request $request)
    {
        $request->validate([
            'action' => ['required', 'in:delete,restore,force_delete,status_new,status_contacted,status_quoted,status_confirmed,status_cancelled'],
            'ids'    => ['required', 'array'],
            'ids.*'  => ['integer'],
        ]);

        $ids    = $request->ids;
        $action = $request->action;

        if ($action === 'delete') {
            BulkOrder::whereIn('id', $ids)->delete();
            return response()->json(['status' => true, 'message' => 'Selected orders moved to trash.']);
        }

        if ($action === 'restore') {
            BulkOrder::onlyTrashed()->whereIn('id', $ids)->restore();
            return response()->json(['status' => true, 'message' => 'Selected orders restored.']);
        }

        if ($action === 'force_delete') {
            BulkOrder::onlyTrashed()->whereIn('id', $ids)->forceDelete();
            return response()->json(['status' => true, 'message' => 'Selected orders permanently deleted.']);
        }

        // Handle Bulk Status Updates
        $statusMap = [
            'status_new'       => BulkOrder::STATUS_NEW,
            'status_contacted' => BulkOrder::STATUS_CONTACTED,
            'status_quoted'    => BulkOrder::STATUS_QUOTED,
            'status_confirmed' => BulkOrder::STATUS_CONFIRMED,
            'status_cancelled' => BulkOrder::STATUS_CANCELLED,
        ];

        if (array_key_exists($action, $statusMap)) {
            BulkOrder::whereIn('id', $ids)->update(['status' => $statusMap[$action]]);
            return response()->json(['status' => true, 'message' => 'Selected orders status updated.']);
        }

        return response()->json(['status' => false, 'message' => 'Invalid action.'], 422);
    }
}
