<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use App\Models\Campaign;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    /**
     * Check if the user is an admin.
     */
    private function adminOnly(): void
    {
        if (! auth()->user()->isAdmin()) {
            abort(403, 'Unauthorized access.');
        }
    }

    /**
     * Base query for FAQs.
     */
    private function faqQuery(bool $trash = false): Builder
    {
        $query = $trash ? Faq::onlyTrashed() : Faq::query();
        return $query->with('campaign')->latest();
    }

    /**
     * Apply Search and Filters.
     */
    private function applyFilters(Builder $query, Request $request): Builder
    {
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('question', 'like', "%{$search}%")
                  ->orWhere('answer', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', (bool) $request->status);
        }

        if ($request->filled('campaign_id') && $request->campaign_id !== 'all') {
            $query->where('campaign_id', $request->campaign_id);
        }

        return $query;
    }

    /**
     * Reusable list response for Index & Trash.
     */
    private function listResponse(Request $request, Builder $query, string $title, bool $isTrash = false)
    {
        $query = $this->applyFilters($query, $request);
        $faqs = $query->paginate(15);
        $campaigns = Campaign::active()->select('id', 'title')->get();

        $breadcrumb = [
            ['text' => 'Dashboard', 'url' => route('admin.dashboard')],
            ['text' => 'FAQ', 'url' => route('admin.faqs.index')],
        ];

        if ($isTrash) {
            $breadcrumb[] = [
                'text' => 'Trash',
                'url' => route('admin.faqs.trashed'),
            ];
        }

        if ($request->ajax()) {
            return response()->json([
                'status' => true,
                'html' => view('admin.faqs.partials.table', [
                    'faqs' => $faqs,
                    'isTrash' => $isTrash,
                ])->render(),
            ]);
        }

        return view('admin.faqs.index', [
            'faqs' => $faqs,
            'campaigns' => $campaigns,
            'title' => $title,
            'breadcrumb' => $breadcrumb,
            'isTrash' => $isTrash,
        ]);
    }

    public function index(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->faqQuery(), 'All FAQs');
    }

    public function trash(Request $request)
    {
        $this->adminOnly();
        return $this->listResponse($request, $this->faqQuery(true), 'Trashed FAQs', true);
    }

    public function create(Request $request)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.faqs.index');
        }

        $faq = null;
        $isEdit = false;
        $action = route('admin.faqs.store');
        $campaigns = Campaign::active()->select('id', 'title')->get();

        return response()->json([
            'status' => true,
            'html' => view('admin.faqs.partials.form', compact('faq', 'isEdit', 'action', 'campaigns'))->render(),
        ]);
    }

    public function store(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'campaign_id' => ['nullable', 'exists:campaigns,id'],
            'question' => ['required', 'string', 'max:255'],
            'answer' => ['nullable', 'string'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'status' => ['nullable', 'boolean'],
        ]);

        Faq::create([
            'campaign_id' => $request->campaign_id,
            'question' => $request->question,
            'answer' => $request->answer,
            'sort_order' => $request->sort_order ?? 0,
            'status' => $request->has('status') ? true : false,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'FAQ created successfully.',
        ]);
    }

    public function show(Request $request, Faq $faq)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.faqs.index');
        }

        $faq->load('campaign');

        return response()->json([
            'status' => true,
            'html' => view('admin.faqs.partials.show', compact('faq'))->render(),
        ]);
    }

    public function edit(Request $request, Faq $faq)
    {
        $this->adminOnly();

        if (! $request->ajax()) {
            return redirect()->route('admin.faqs.index');
        }

        $isEdit = true;
        $action = route('admin.faqs.update', $faq->id);
        $campaigns = Campaign::active()->select('id', 'title')->get();

        return response()->json([
            'status' => true,
            'html' => view('admin.faqs.partials.form', compact('faq', 'isEdit', 'action', 'campaigns'))->render(),
        ]);
    }

    public function update(Request $request, Faq $faq)
    {
        $this->adminOnly();

        $request->validate([
            'campaign_id' => ['nullable', 'exists:campaigns,id'],
            'question' => ['required', 'string', 'max:255'],
            'answer' => ['nullable', 'string'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $faq->update([
            'campaign_id' => $request->campaign_id,
            'question' => $request->question,
            'answer' => $request->answer,
            'sort_order' => $request->sort_order ?? 0,
            'status' => $request->has('status'),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'FAQ updated successfully.',
        ]);
    }

    public function updateStatus(Request $request, Faq $faq)
    {
        $this->adminOnly();

        $request->validate([
            'status' => ['required', 'boolean'],
        ]);

        $faq->update(['status' => $request->status]);

        return response()->json([
            'status' => true,
            'message' => 'Status updated successfully.',
        ]);
    }

    public function destroy(Faq $faq)
    {
        $this->adminOnly();
        $faq->delete();

        return response()->json([
            'status' => true,
            'message' => 'FAQ moved to trash successfully.',
        ]);
    }

    public function restore($id)
    {
        $this->adminOnly();
        Faq::onlyTrashed()->findOrFail($id)->restore();

        return response()->json([
            'status' => true,
            'message' => 'FAQ restored successfully.',
        ]);
    }

    public function forceDelete($id)
    {
        $this->adminOnly();
        Faq::onlyTrashed()->findOrFail($id)->forceDelete();

        return response()->json([
            'status' => true,
            'message' => 'FAQ permanently deleted.',
        ]);
    }

    public function multipleAction(Request $request)
    {
        $this->adminOnly();

        $request->validate([
            'action' => ['required', 'in:delete,restore,force_delete,active,inactive'],
            'ids' => ['required', 'array'],
            'ids.*' => ['integer'],
        ]);

        $ids = $request->ids;
        $action = $request->action;

        if ($action === 'delete') {
            Faq::whereIn('id', $ids)->delete();
            return response()->json(['status' => true, 'message' => 'Selected FAQs moved to trash.']);
        }

        if ($action === 'restore') {
            Faq::onlyTrashed()->whereIn('id', $ids)->restore();
            return response()->json(['status' => true, 'message' => 'Selected FAQs restored.']);
        }

        if ($action === 'force_delete') {
            Faq::onlyTrashed()->whereIn('id', $ids)->forceDelete();
            return response()->json(['status' => true, 'message' => 'Selected FAQs permanently deleted.']);
        }

        $status = $action === 'active' ? true : false;
        Faq::whereIn('id', $ids)->update(['status' => $status]);

        return response()->json([
            'status' => true,
            'message' => 'Selected FAQs status updated.',
        ]);
    }
}