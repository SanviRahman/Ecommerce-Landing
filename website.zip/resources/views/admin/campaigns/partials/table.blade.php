@php
    $isTrash = $isTrash ?? false;
@endphp

<div class="table-responsive">
    <table class="table table-hover mb-0">
        <thead class="thead-light">
            <tr>
                <th style="width: 45px;">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox"
                               class="custom-control-input"
                               id="check_all">
                        <label class="custom-control-label" for="check_all"></label>
                    </div>
                </th>

                <th style="width: 70px;">SL</th>
                <th>Landing Page Title</th>
                <th>Public URL</th>
                <th>Products</th>
                <th style="width: 120px;">Default</th>
                <th style="width: 110px;">Status</th>
                <th style="width: 230px;">Action</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($campaigns as $campaign)
                <tr>
                    <td>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox"
                                   class="custom-control-input row-checkbox"
                                   id="campaign_check_{{ $campaign->id }}"
                                   value="{{ $campaign->id }}">
                            <label class="custom-control-label" for="campaign_check_{{ $campaign->id }}"></label>
                        </div>
                    </td>

                    <td>{{ $campaigns->firstItem() + $loop->index }}</td>

                    <td>
                        <strong>{{ $campaign->title }}</strong>
                    </td>

                    <td>
                        <div class="mb-1">
                            <span class="badge {{ $campaign->usesCustomRoute() ? 'badge-warning' : 'badge-info' }}">
                                {{ $campaign->usesCustomRoute() ? 'Custom' : 'Standard' }}
                            </span>
                        </div>

                        <a href="{{ $campaign->public_url }}"
                           target="_blank"
                           class="small font-weight-bold text-break">
                            {{ $campaign->public_path }}
                        </a>
                    </td>

                    <td>
                        @if ($campaign->products && $campaign->products->count())
                            @foreach ($campaign->products->take(3) as $product)
                                <span class="badge badge-info mb-1">
                                    {{ $product->name }}
                                </span>
                            @endforeach

                            @if ($campaign->products->count() > 3)
                                <span class="badge badge-secondary">
                                    +{{ $campaign->products->count() - 3 }} more
                                </span>
                            @endif
                        @else
                            <span class="text-muted">No product</span>
                        @endif
                    </td>

                    <td class="text-center">
                        <div class="custom-control custom-switch campaign-default-switch d-inline-block">
                            <input type="checkbox"
                                   class="custom-control-input btnSetDefaultCampaign"
                                   id="campaign_default_{{ $campaign->id }}"
                                   data-url="{{ route('admin.campaigns.set_default', $campaign->id) }}"
                                   data-default="{{ $campaign->is_default ? 1 : 0 }}"
                                   @checked($campaign->is_default)
                                   @disabled($isTrash)>
                            <label class="custom-control-label" for="campaign_default_{{ $campaign->id }}">
                                {{ $campaign->is_default ? 'Default' : 'Set' }}
                            </label>
                        </div>
                    </td>

                    <td>
                        @if ($campaign->status)
                            <span class="badge badge-success">Active</span>
                        @else
                            <span class="badge badge-danger">Inactive</span>
                        @endif
                    </td>

                    <td>
                        @if (! $isTrash)
                            <a href="{{ $campaign->public_url }}"
                               target="_blank"
                               class="btn btn-sm btn-primary"
                               title="View Landing Page">
                                <i class="fas fa-eye"></i>
                            </a>

                            <a href="{{ route('admin.campaigns.show', $campaign->id) }}"
                               class="btn btn-sm btn-dark"
                               title="Admin Details">
                                <i class="fas fa-desktop"></i>
                            </a>

                            <a href="{{ route('admin.campaigns.edit', $campaign->id) }}"
                               class="btn btn-sm btn-info"
                               title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>

                            <button type="button"
                                    class="btn btn-sm btn-danger btnDelete"
                                    data-url="{{ route('admin.campaigns.destroy', $campaign->id) }}"
                                    title="Move to Trash">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        @else
                            <button type="button"
                                    class="btn btn-sm btn-success btnRestore"
                                    data-url="{{ route('admin.campaigns.restore', $campaign->id) }}"
                                    title="Restore">
                                <i class="fas fa-trash-restore"></i>
                            </button>

                            <button type="button"
                                    class="btn btn-sm btn-danger btnForceDelete"
                                    data-url="{{ route('admin.campaigns.force_delete', $campaign->id) }}"
                                    title="Purge Permanently">
                                <i class="fas fa-times"></i>
                            </button>
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">
                        No campaigns found.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

@if ($campaigns->hasPages())
    <div class="px-4 py-3 border-top bg-white">
        {{ $campaigns->withQueryString()->links() }}
    </div>
@endif
