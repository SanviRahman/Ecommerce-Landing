<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('courier_accounts', 'settings')) {
            Schema::table('courier_accounts', function (Blueprint $table) {
                $table->json('settings')->nullable()->after('token');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('courier_accounts', 'settings')) {
            Schema::table('courier_accounts', function (Blueprint $table) {
                $table->dropColumn('settings');
            });
        }
    }
};