<li <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>" <?php endif; ?> class="nav-item">
    <?php if(strtoupper((string) ($item['method'] ?? 'GET')) === 'POST'): ?>
        <form method="POST" action="<?php echo e($item['href']); ?>" class="m-0"
              onsubmit="return confirm('Run this administrator maintenance action?');">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="nav-link w-100 text-left border-0 <?php echo e($item['class']); ?> <?php if(isset($item['shift'])): ?> <?php echo e($item['shift']); ?> <?php endif; ?>"
                    style="background: transparent; cursor: pointer;"
                    <?php echo $item['data-compiled'] ?? ''; ?>>
                <i class="nav-icon <?php echo e($item['icon'] ?? 'far fa-fw fa-circle'); ?> <?php echo e(isset($item['icon_color']) ? 'text-'.$item['icon_color'] : ''); ?>"></i>
                <p><?php echo e($item['text']); ?></p>
            </button>
        </form>
    <?php else: ?>
        <a class="nav-link <?php echo e($item['class']); ?> <?php if(isset($item['shift'])): ?> <?php echo e($item['shift']); ?> <?php endif; ?>"
           href="<?php echo e($item['href']); ?>" <?php if(isset($item['target'])): ?> target="<?php echo e($item['target']); ?>" <?php endif; ?>
           <?php echo $item['data-compiled'] ?? ''; ?>>
            <i class="nav-icon <?php echo e($item['icon'] ?? 'far fa-fw fa-circle'); ?> <?php echo e(isset($item['icon_color']) ? 'text-'.$item['icon_color'] : ''); ?>"></i>
            <p>
                <?php echo e($item['text']); ?>

                <?php if(isset($item['label'])): ?>
                    <span class="badge badge-<?php echo e($item['label_color'] ?? 'primary'); ?> right">
                        <?php echo e($item['label']); ?>

                    </span>
                <?php endif; ?>
            </p>
        </a>
    <?php endif; ?>
</li>
<?php /**PATH D:\Ecommerce-Landing\website\resources\views\vendor\adminlte/partials/sidebar/menu-item-link.blade.php ENDPATH**/ ?>