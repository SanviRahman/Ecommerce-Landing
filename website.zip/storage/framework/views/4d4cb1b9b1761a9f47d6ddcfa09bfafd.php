<?php
    $commerceActive = request()->attributes->get('p26_isolated_commerce_qa', false) === true
        || request()->attributes->get('p32_local_commerce', false) === true
        || request()->attributes->get('p58_production_commerce') === true;
    $branding = app(\App\Support\StorefrontBranding::class);
    $details = app(\App\Support\StorefrontContactDetails::class)->get();
    $brandName = $branding->name();
    $brandLogo = $branding->logo();
    $socialLinks = $branding->socialLinks();
?>
<footer class="p07-footer p19-footer p37-footer" id="storefront-footer">
    <div class="p07-container">
        
        <?php if(request()->routeIs('home') && !request()->attributes->get('p25_local_readonly_browse', false)): ?>
            <section class="p53-home-track" id="home-order-tracking" aria-labelledby="p53-home-track-title">
                <div class="p53-track-copy">
                    <span class="p53-track-eyebrow">ORDER UPDATES</span>
                    <h2 id="p53-home-track-title">Track your order</h2>
                    <p>Ordered from our Homepage or a Campaign? Use the phone number from your order to see its latest courier status.</p>
                    <a href="<?php echo e(route('order.track')); ?>">Open full tracking page →</a>
                </div>
                <div class="p53-track-widget">
                    <form method="POST" action="<?php echo e(route('order.track.search')); ?>" data-storefront-track>
                        <?php echo csrf_field(); ?>
                        <label for="p53-home-track-phone">Order phone number</label>
                        <div class="p53-track-fields">
                            <input id="p53-home-track-phone" type="tel" name="tracking_phone"
                                inputmode="numeric" autocomplete="tel" maxlength="11"
                                pattern="01[0-9]{9}" placeholder="01XXXXXXXXX" required>
                            <button type="submit">Track Order →</button>
                        </div>
                    </form>
                    <div class="p53-track-results" data-track-results role="status" aria-live="polite"></div>
                </div>
            </section>
        <?php endif; ?>
        <div class="p19-newsletter p37-newsletter"><div><span class="p19-caption">EXPLORE THE COLLECTION</span>
            <h2>Quality products. Better shopping.</h2><p>Explore the latest arrivals and carefully organized categories.</p>
        </div><a class="p19-newsletter-cta" href="<?php echo e(route('storefront.shop')); ?>">Explore Products <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a></div>
        <div class="p19-footer-grid p37-footer-grid">
            <div class="p33-footer-about p37-footer-about">
                <a class="p19-footer-brand p33-footer-brand" href="<?php echo e(route('home')); ?>">
                    <?php if($brandLogo): ?><img src="<?php echo e($brandLogo); ?>" alt="" class="p33-footer-logo" loading="lazy"><?php else: ?><span class="p33-footer-logo-fallback" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($brandName, 0, 1))); ?></span><?php endif; ?>
                    <span><?php echo e($brandName); ?><small>Shop smart · Live better</small></span>
                </a>
                <?php if($details['description']): ?><p><?php echo e($details['description']); ?></p><?php else: ?><p>Discover our products and collections, all in one place.</p><?php endif; ?>
                <?php if($socialLinks->isNotEmpty()): ?>
                    <nav class="p33-social-links p37-social-links" aria-label="Official social media profiles">
                        <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social['url']); ?>" <?php if (! ($social['platform'] === 'phone')): ?> target="_blank" rel="noopener noreferrer" <?php endif; ?>
                               class="p33-social-icon p33-social-<?php echo e($social['platform']); ?>"
                               aria-label="<?php echo e($social['label']); ?>" title="<?php echo e($social['label']); ?>">
                                <?php echo $__env->make('storefront.partials.social-icon', ['platform' => $social['platform']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                <?php endif; ?>
            </div>
            <nav class="p37-footer-links" aria-label="Quick Links"><h3>Quick Links</h3>
                <a href="<?php echo e(route('home')); ?>">Home</a><a href="<?php echo e(route('storefront.shop')); ?>">Shop All Products</a>
                <a href="<?php echo e(route('home')); ?>#categories">Shop by Category</a>
                <a href="<?php echo e(route('storefront.wishlist')); ?>">My Wishlist</a>
                <a href="<?php echo e(route('storefront.contact')); ?>">Contact Us</a>
            </nav>
            <nav class="p37-footer-links" aria-label="Customer Care"><h3>Customer Care</h3>
                <a href="<?php echo e(route('order.track')); ?>">Track My Order</a>
                <?php if($commerceActive && config('storefront.p08_cart_test_enabled', false)): ?><a href="<?php echo e(route('storefront.cart')); ?>">My Cart</a><?php endif; ?>
                <?php if($commerceActive && config('storefront.p08_checkout_test_enabled', false)): ?><a href="<?php echo e(route('storefront.checkout')); ?>">Checkout</a><?php endif; ?>
                <?php if($commerceActive): ?><a href="<?php echo e(route('storefront.account.login')); ?>">Login / Register</a><?php endif; ?>
                <a href="<?php echo e(route('storefront.help')); ?>">FAQ / Support</a>
            </nav>
            <div class="p37-footer-contact"><h3>Contact Us</h3>
                <?php if($details['address']): ?><div class="p37-footer-contact-row"><span class="p37-footer-contact-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'pin'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span><?php echo e($details['address']); ?></span></div><?php endif; ?>
                <?php if($details['phone']): ?><a class="p37-footer-contact-row" href="<?php echo e($details['phone_href']); ?>"><span class="p37-footer-contact-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'phone'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span><?php echo e($details['phone']); ?></span></a><?php endif; ?>
                <?php if($details['email']): ?><a class="p37-footer-contact-row" href="<?php echo e($details['email_href']); ?>"><span class="p37-footer-contact-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'mail'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span><?php echo e($details['email']); ?></span></a><?php endif; ?>
                <?php if($details['working_hours']): ?><div class="p37-footer-contact-row"><span class="p37-footer-contact-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'clock'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span><?php echo e($details['working_hours']); ?></span></div><?php endif; ?>
                <?php if (! ($details['address'] || $details['phone'] || $details['email'])): ?><p>Contact details will be shown when configured in Site Settings.</p><?php endif; ?>
                <a class="p37-footer-contact-cta" href="<?php echo e(route('storefront.contact')); ?>">Send us a message →</a>
            </div>
        </div>
        <div class="p19-footer-bottom p37-footer-bottom"><span>© <?php echo e(now()->year); ?> <?php echo e($brandName); ?>. All rights reserved.</span></div>
    </div>
</footer>
<?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/partials/footer.blade.php ENDPATH**/ ?>