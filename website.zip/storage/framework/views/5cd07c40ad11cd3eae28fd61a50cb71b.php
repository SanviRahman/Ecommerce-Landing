<?php
    $branding = app(\App\Support\StorefrontBranding::class);
    $brandName = $branding->name();
    $brandLogo = $branding->logo();
    $commerceActive = request()->attributes->get('p26_isolated_commerce_qa', false) === true
        || request()->attributes->get('p32_local_commerce', false) === true
        || request()->attributes->get('p58_production_commerce') === true;
    $checkoutActive = $commerceActive && config('storefront.p08_checkout_test_enabled', false) === true
        && config('storefront.p03_core_test_enabled', false) === true;
    $wishlistState = app(\App\Support\StorefrontWishlistState::class);
    $wishSignedIn = $wishlistState->authenticated();
    $wishCount = $wishlistState->count();
    $wishlistHref = $wishSignedIn ? route('storefront.wishlist') : route('storefront.account.login');
    $cartActive = $commerceActive && config('storefront.p08_cart_test_enabled', false) === true;
    $account = $commerceActive ? \Illuminate\Support\Facades\Auth::guard('storefront')->user() : null;
?>
<header class="p07-header p19-header" data-sticky-header>
    <div class="p19-benefit-bar"><div class="p07-container">
        <span><?php echo $__env->make('storefront.partials.icon', ['name'=>'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Explore our collection</span>
        <span><?php echo $__env->make('storefront.partials.icon', ['name'=>'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Discover products</span>
        <span><?php echo $__env->make('storefront.partials.icon', ['name'=>'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Support when you need it</span>
        <a href="<?php echo e(route('order.track')); ?>">Track Order</a>
    </div></div>
    <div class="p07-container p19-main-header">
        <button type="button" class="p59-header-menu" data-menu-open aria-label="Open category menu" aria-controls="p19-category-menu-drawer" aria-expanded="false">
            <?php echo $__env->make('storefront.partials.icon', ['name'=>'menu'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </button>
        <a class="p07-brand p33-logo-brand" href="<?php echo e(route('home')); ?>" aria-label="<?php echo e($brandName); ?> homepage">
            <?php if($brandLogo): ?>
                <img class="p33-site-logo" src="<?php echo e($brandLogo); ?>" alt="" loading="eager" decoding="async">
            <?php else: ?>
                <span class="p07-brand-logo" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($brandName, 0, 1))); ?></span>
            <?php endif; ?>
            <span class="p33-brand-name"><?php echo e($brandName); ?><small>Shop smart · Live better</small></span>
        </a>
        <form class="p07-search p19-search" method="GET" action="<?php echo e(route('storefront.shop')); ?>" role="search" id="p19-search-form">
            <label class="p07-visually-hidden" for="p07-header-search">Search products and categories</label>
            <input id="p07-header-search" type="search" name="q" placeholder="Search for products..." maxlength="80"
                value="<?php echo e(request()->routeIs('storefront.shop') ? request('q', '') : ''); ?>">
            <button type="submit" aria-label="Search products"><?php echo $__env->make('storefront.partials.icon', ['name'=>'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span>Search</span></button>
        </form>
        <div class="p19-header-actions p33-header-actions p34-header-actions">
            <?php if($commerceActive): ?>
                <a href="<?php echo e(route('storefront.account.index')); ?>" class="p19-account-link p33-account" aria-label="My Account<?php echo e($account ? ': '. $account->name : ' — Login or Register'); ?>">
                    <span class="p33-action-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'account'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                    <span class="p33-action-copy"><strong><?php echo e($account ? \Illuminate\Support\Str::limit($account->name, 18) : 'My Account'); ?></strong><small><?php echo e($account ? 'View profile' : 'Login / Register'); ?></small></span>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('storefront.shop')); ?>" class="p19-account-link p33-account" aria-label="Browse products">
                    <span class="p33-action-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'bag'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                    <span class="p33-action-copy"><strong>Shop Products</strong></span>
                </a>
            <?php endif; ?>
            <a href="<?php echo e($wishlistHref); ?>" class="p19-account-link p32-nav-wishlist p33-wishlist" aria-label="<?php echo e($wishSignedIn ? 'Wishlist, '.$wishCount.' saved items' : 'Log in to use Wishlist'); ?>">
                <span class="p33-action-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><b class="p33-count-badge" data-wishlist-count><?php echo e($wishCount); ?></b></span>
                <span class="p33-action-copy"><strong>Wishlist</strong><small><?php echo e($wishCount); ?> saved items</small></span>
            </a>
            <?php if($cartActive): ?>
                <button type="button" data-cart-open class="p19-top-cart p33-cart-link" aria-label="Open shopping cart">
                    <span class="p33-action-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><b class="p33-count-badge" data-cart-count>…</b></span>
                    <span class="p33-action-copy"><strong>Cart</strong><small>৳<b data-cart-total>…</b></small></span>
                </button>
            <?php endif; ?>
        </div>
    </div>
    <nav class="p19-desktop-nav" aria-label="Primary navigation"><div class="p07-container p19-desktop-nav-inner">
        <details class="p19-mega-menu" data-categories-menu>
            <summary><?php echo $__env->make('storefront.partials.icon', ['name'=>'grid'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <span>All Categories</span><?php echo $__env->make('storefront.partials.icon', ['name'=>'chevron-down', 'class'=>'p34-mega-chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></summary>
            <div class="p19-mega-panel">
                <div class="p52-menu-intro"><span>EXPLORE COLLECTIONS</span><strong>Find your next favorite</strong></div>
                <?php $__empty_1 = true; $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        // Visual-only icons; never infer category or product data from the label.
                        $categoryIcons = ['beauty'=>'sparkles','clothing'=>'shirt','electronics'=>'monitor',
                            'home-kitchen'=>'home','home-and-kitchen'=>'home','natural-oil'=>'leaf','organic-food'=>'leaf'];
                        $categoryIcon = $categoryIcons[$parent->slug] ?? 'grid';
                    ?>
                    <details class="p19-parent-category">
                        <summary>
                            <span class="p39-category-label"><?php echo $__env->make('storefront.partials.icon', ['name'=>$categoryIcon], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php echo e($parent->name); ?></span>
                            <?php if($parent->children->isNotEmpty()): ?>
                                <span class="p40-subcategory-count" aria-label="<?php echo e($parent->children->count()); ?> subcategories"><?php echo e($parent->children->count()); ?></span>
                            <?php endif; ?>
                            <?php echo $__env->make('storefront.partials.icon', ['name'=>'chevron-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </summary>
                        <div class="p19-category-children">
                            <a href="<?php echo e(route('storefront.category', $parent->slug)); ?>"
                               <?php if(request()->routeIs('storefront.category') && request()->route('slug') === $parent->slug): ?> aria-current="page" <?php endif; ?>>All <?php echo e($parent->name); ?></a>
                            <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('storefront.category', $child->slug)); ?>"
                                   <?php if(request()->routeIs('storefront.category') && request()->route('slug') === $child->slug): ?> aria-current="page" <?php endif; ?>><?php echo e($child->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p>No active categories</p> <?php endif; ?>
            </div>
        </details>
        <a href="<?php echo e(route('home')); ?>" <?php if(request()->routeIs('home', 'storefront.home')): ?> aria-current="page" <?php endif; ?>>Home</a>
        <a href="<?php echo e(route('storefront.shop')); ?>">Shop</a>
        <a href="<?php echo e(route('storefront.shop', ['sort'=>'newest'])); ?>">New Arrivals</a>
        <a href="<?php echo e(route('home')); ?>#categories">Categories</a>
        <a href="<?php echo e(route('storefront.help')); ?>">Help</a>
        <a href="<?php echo e(route('storefront.contact')); ?>">Contact</a>
        <a href="<?php echo e(route('order.track')); ?>">Track Order</a>
    </div></nav>
</header>
<div class="p19-mobile-search-panel" data-mobile-search hidden>
    <form method="GET" action="<?php echo e(route('storefront.shop')); ?>" role="search">
        <label for="p19-mobile-search-input">Search products</label>
        <div><input id="p19-mobile-search-input" name="q" type="search" placeholder="Search products..." maxlength="80" required>
            <button type="submit" aria-label="Search"><?php echo $__env->make('storefront.partials.icon', ['name'=>'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
            <button type="button" data-search-close aria-label="Close search"><?php echo $__env->make('storefront.partials.icon', ['name'=>'close'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button></div>
    </form>
</div>
<div class="p19-drawer-backdrop" data-drawer-backdrop hidden></div>
<aside id="p19-category-menu-drawer" class="p19-drawer p19-menu-drawer" data-menu-drawer role="dialog" aria-modal="true" aria-labelledby="p19-menu-title" hidden>
    <div class="p19-drawer-head"><h2 id="p19-menu-title">Browse Categories</h2>
        <button type="button" data-drawer-close aria-label="Close menu"><?php echo $__env->make('storefront.partials.icon', ['name'=>'close'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
    </div>
    <nav aria-label="Categories and shopping" class="p19-drawer-scroll">
        <a class="p19-drawer-link" href="<?php echo e(route('home')); ?>"><?php echo $__env->make('storefront.partials.icon', ['name'=>'home'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Home</a>
        <a class="p19-drawer-link" href="<?php echo e(route('storefront.shop')); ?>"><?php echo $__env->make('storefront.partials.icon', ['name'=>'grid'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Shop All Products</a>
        <a class="p19-drawer-link" href="<?php echo e($wishlistHref); ?>"><?php echo $__env->make('storefront.partials.icon', ['name'=>'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> My Wishlist</a>
        <?php if($cartActive): ?><a class="p19-drawer-link" href="<?php echo e(route('storefront.cart')); ?>"><?php echo $__env->make('storefront.partials.icon', ['name'=>'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> My Cart</a><?php endif; ?>
        <?php if($checkoutActive): ?><a class="p19-drawer-link" href="<?php echo e(route('storefront.checkout')); ?>">Secure Checkout</a><?php endif; ?>
        <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <details class="p19-mobile-category"><summary><?php echo e($parent->name); ?>

                <span class="p40-mobile-count"><?php echo e($parent->children->count() ?: '+'); ?></span></summary>
                <a href="<?php echo e(route('storefront.category', $parent->slug)); ?>">All <?php echo e($parent->name); ?></a>
                <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('storefront.category', $child->slug)); ?>"><?php echo e($child->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </details>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($commerceActive): ?>
            <a class="p19-drawer-link" href="<?php echo e(route('storefront.account.index')); ?>"><?php echo $__env->make('storefront.partials.icon', ['name'=>'account'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> My Account</a>
        <?php else: ?>
            <a class="p19-drawer-link" href="<?php echo e(route('storefront.contact')); ?>">Contact Us</a>
        <?php endif; ?>
        <a class="p19-drawer-link" href="<?php echo e(route('order.track')); ?>">Track Order</a>
    </nav>
</aside>
<?php if($cartActive): ?>
    <button type="button" class="p19-floating-cart" data-cart-open
        data-cart-summary-url="<?php echo e(route('storefront.cart.summary')); ?>" aria-label="Open cart and view total">
        <?php echo $__env->make('storefront.partials.icon', ['name'=>'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <b data-cart-count>…</b>
        <span>৳<b data-cart-total>…</b></span>
    </button>
    <button type="button" class="p35-mobile-cart-peek" data-cart-open
        aria-label="Open mini cart" aria-describedby="p35-mobile-cart-label">
        <span class="p35-mini-cart-symbol" aria-hidden="true"><?php echo $__env->make('storefront.partials.icon', ['name'=>'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
        <span class="p35-mini-cart-info" id="p35-mobile-cart-label">
            <strong data-p35-cart-peek-title>Your shopping bag</strong>
            <small><b data-cart-count>…</b> items · ৳<b data-cart-total>…</b></small>
        </span>
        <span class="p35-mini-cart-action" data-p35-cart-peek-action>Open cart <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
    </button>
    <aside class="p19-drawer p19-cart-drawer" data-cart-drawer role="dialog" aria-modal="true" aria-labelledby="p19-cart-title" hidden>
        <div class="p19-drawer-head"><h2 id="p19-cart-title">Your Mini Cart</h2>
            <button type="button" data-drawer-close aria-label="Close cart"><?php echo $__env->make('storefront.partials.icon', ['name'=>'close'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
        </div>
        <div class="p19-drawer-scroll" data-cart-lines><p>Loading your cart…</p></div>
        <div class="p19-cart-drawer-footer"><div>Subtotal: <strong>৳<span data-cart-total>0.00</span></strong></div>
            <a href="<?php echo e(route('storefront.cart')); ?>">View Cart</a>
            <?php if($checkoutActive): ?><a class="p19-cart-checkout" href="<?php echo e(route('storefront.checkout')); ?>">Checkout →</a><?php endif; ?>
        </div>
    </aside>
<?php endif; ?>
<nav class="p07-mobile-nav p19-mobile-nav p34-mobile-nav" aria-label="Mobile navigation">
    <a href="<?php echo e(route('home')); ?>" <?php if(request()->routeIs('home', 'storefront.home')): ?> aria-current="page" <?php endif; ?>>
        <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'home'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span class="p34-mobile-text">Home</span>
    </a>
    <button type="button" data-menu-open aria-label="Open category menu" aria-controls="p19-category-menu-drawer" aria-expanded="false">
        <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'grid'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span class="p34-mobile-text">Menu</span>
    </button>
    <?php if($cartActive): ?>
        <button type="button" data-cart-open class="p34-bottom-cart" aria-label="Open cart">
            <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><b class="p34-nav-count" data-cart-count>…</b></span>
            <span class="p34-mobile-text">Cart</span>
        </button>
    <?php endif; ?>
    <button type="button" data-search-open aria-label="Search products">
        <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span class="p34-mobile-text">Search</span>
    </button>
    <?php if($commerceActive): ?>
        <a href="<?php echo e(route('storefront.account.index')); ?>" <?php if(request()->routeIs('storefront.account.*')): ?> aria-current="page" <?php endif; ?> aria-label="My Account">
            <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'account'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span class="p34-mobile-text">Account</span>
        </a>
    <?php else: ?>
        <a href="<?php echo e(route('storefront.contact')); ?>" aria-label="Contact support">
            <span class="p34-bottom-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'headphones'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><span class="p34-mobile-text">Contact</span>
        </a>
    <?php endif; ?>
</nav>
<?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/partials/navigation.blade.php ENDPATH**/ ?>