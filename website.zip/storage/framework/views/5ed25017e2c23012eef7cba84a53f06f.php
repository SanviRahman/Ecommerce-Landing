<?php $__env->startSection('title', 'Secure Checkout'); ?>
<?php $__env->startSection('content'); ?>
    <?php $shopper = \Illuminate\Support\Facades\Auth::guard('storefront')->user(); ?>
    <div hidden data-p53-checkout-tracking="<?php echo e(json_encode([
        'currency' => 'BDT',
        'value' => (float) $cart['subtotal'],
        'items' => array_map(static fn ($line) => [
            'item_id' => (string) $line['product_id'],
            'item_name' => (string) $line['name'],
            'price' => (float) $line['unit_price'],
            'quantity' => (int) $line['quantity'],
        ], $cart['lines']),
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR)); ?>"></div>
    <div class="p50-checkout-intro">
    <div class="p19-checkout-heading" data-reveal><p class="p19-caption">SECURE CASH ON DELIVERY CHECKOUT</p>
        <h1>Complete Your <span>Order</span></h1><p>Enter shipping details, confirm payment method, review your order and place it securely.</p>
    </div>
    <ol class="p19-checkout-steps" aria-label="Checkout steps" data-step-indicator>
        <?php $__currentLoopData = ['Shipping','Payment','Review','Order Placed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e($loop->first ? 'is-current' : ''); ?>" data-step-indicator-item="<?php echo e($loop->iteration); ?>"
                <?php if($loop->first): ?> aria-current="step" <?php endif; ?>><span class="p50-step-number"><?php echo e($loop->iteration); ?></span><span class="p50-step-label"><?php echo e($name); ?></span></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    </div>
    <?php if($errors->any()): ?><div class="p08-error" role="alert"><strong>Please check these details:</strong>
        <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($message); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <div class="p08-checkout-grid p19-checkout-grid">
        <form id="p08-checkout-form" method="POST" action="<?php echo e(route('storefront.checkout.place')); ?>"
            class="p08-checkout-form p19-checkout-form" data-checkout-stepper>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="checkout_key" value="<?php echo e(old('checkout_key', $checkoutKey)); ?>">
            <input type="hidden" name="cart_version" value="<?php echo e($cart['version']); ?>">
            <fieldset class="p19-step-panel" data-checkout-step="1"><legend><span class="p50-step-legend-inner"><span class="p50-step-legend-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'truck'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>Shipping Information</span></legend>
                <p class="p19-step-subtitle">Where should we deliver your order?</p>
                <div class="p19-form-row">
                    <div><label for="p08-customer-name">Full Name <span>*</span></label>
                        <input id="p08-customer-name" name="customer_name" maxlength="255"
                            value="<?php echo e(old('customer_name', $shopper?->name)); ?>" autocomplete="name" required></div>
                    <div><label for="p08-phone">Phone Number <span>*</span></label>
                        <input id="p08-phone" name="phone" inputmode="tel" pattern="01[0-9]{9}" maxlength="11"
                            value="<?php echo e(old('phone', $shopper?->phone)); ?>" placeholder="01XXXXXXXXX" autocomplete="tel" required></div>
                </div>
                <label for="p08-address">Complete Delivery Address <span>*</span></label>
                <textarea id="p08-address" name="address" rows="3" minlength="8" maxlength="2000"
                    autocomplete="street-address" required><?php echo e(old('address', $shopper?->address)); ?></textarea>
                <fieldset class="p61-shipping-areas" aria-describedby="p61-shipping-hint">
                    <legend>Delivery Area <span aria-hidden="true">*</span></legend>
                    <p id="p61-shipping-hint">Select one delivery location to calculate the charge.</p>
                    <div class="p61-area-grid" id="p08-area">
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="p61-area-option">
                                <input type="radio" name="shipping_area_id" value="<?php echo e($area->id); ?>"
                                    data-shipping-area data-shipping-cost="<?php echo e($area->delivery_charge); ?>"
                                    <?php if((string)old('shipping_area_id')===(string)$area->id): echo 'checked'; endif; ?> required>
                                <span><strong><?php echo e($area->area_name); ?></strong><small>৳<?php echo e(number_format($area->delivery_charge)); ?></small></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </fieldset>
                <label for="p08-note">Order note (optional)</label>
                <textarea id="p08-note" name="customer_note" rows="2" maxlength="1000"><?php echo e(old('customer_note')); ?></textarea>
                <p class="p08-help">The final price, stock and shipping charge are recalculated by the server before placing your order.</p>
                <button type="button" class="p08-primary p19-next-btn" data-step-next="2" <?php if($areas->isEmpty()): echo 'disabled'; endif; ?>>Continue to Payment →</button>
                <?php if($areas->isEmpty()): ?><p class="p08-error">Delivery areas are not configured; checkout is unavailable.</p><?php endif; ?>
            </fieldset>
            <fieldset class="p19-step-panel" data-checkout-step="2"><legend><span class="p50-step-legend-inner"><span class="p50-step-legend-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'shield'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>Payment Method</span></legend>
                <p class="p19-step-subtitle">Choose a payment method available at this store.</p>
                <label class="p19-payment-choice"><input type="radio" name="payment_display" checked disabled>
                    <span><strong>Cash on Delivery</strong><small>Pay when your order is delivered</small></span></label>
                <p class="p19-note">Online cards, bKash and Nagad are not enabled for this protected checkout.</p>
                <div class="p19-form-actions"><button type="button" data-step-back="1">← Shipping</button>
                    <button type="button" class="p08-primary" data-step-next="3">Review Order →</button></div>
            </fieldset>
            <fieldset class="p19-step-panel" data-checkout-step="3"><legend><span class="p50-step-legend-inner"><span class="p50-step-legend-icon"><?php echo $__env->make('storefront.partials.icon', ['name'=>'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>Review Your Order</span></legend>
                <p class="p19-step-subtitle">Verify your shipping details and items before submitting.</p>
                <div class="p19-review-shipping" data-review-shipping></div>
                <div class="p19-review-lines">
                    <?php $__currentLoopData = $cart['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($line['name']); ?> × <?php echo e($line['quantity']); ?> <strong>৳<?php echo e($line['line_total']); ?></strong></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="p19-review-totals"><p>Subtotal <strong>৳<?php echo e($cart['subtotal']); ?></strong></p>
                    <p>Delivery <strong data-shipping-preview>Choose delivery area</strong></p>
                    <p class="p54-review-total">Estimated Total <strong data-checkout-total-preview>Choose delivery area</strong></p></div>
                <p class="p08-help">By placing your order, you confirm that the information is correct. Inventory and price are checked again.</p>
                <div class="p19-form-actions"><button type="button" data-step-back="2">← Payment</button>
                    <button class="p08-primary p08-submit" type="submit" <?php if($areas->isEmpty()): echo 'disabled'; endif; ?>>Place COD Order</button>
                </div>
            </fieldset>
            <noscript><p class="p19-noscript">JavaScript is disabled. The secure server form is fully usable; click Place COD Order below.</p>
                <button class="p08-primary p08-submit" type="submit" <?php if($areas->isEmpty()): echo 'disabled'; endif; ?>>Place COD Order</button></noscript>
        </form>
        <aside class="p08-summary p08-checkout-summary p19-order-summary" aria-label="Order summary" data-reveal>
            <h2>Order Summary <small><?php echo e(count($cart['lines'])); ?> items</small></h2>
            <?php $__currentLoopData = $cart['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p19-summary-product"><span><?php echo e($line['name']); ?><small>Qty: <?php echo e($line['quantity']); ?></small></span><strong>৳<?php echo e($line['line_total']); ?></strong></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr><p>Subtotal <strong>৳<?php echo e($cart['subtotal']); ?></strong></p>
            <p>Shipping <strong data-shipping-preview>Choose delivery area</strong></p>
            <p class="p19-summary-total">Estimated Total <strong data-checkout-total-preview data-subtotal-bdt="<?php echo e($cart['subtotal']); ?>" aria-live="polite">Choose delivery area</strong></p>
            <p class="p54-total-note">Final total, shipping and stock are confirmed by the server when you place the order.</p>
            <a href="<?php echo e(route('storefront.cart')); ?>">← Edit cart</a>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.catalog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/pages/checkout.blade.php ENDPATH**/ ?>