<?php
    /** @var \App\Models\Product $product */
    $available = $catalog->displayStock($product);
    $price = $catalog->displayPrice($product);
    $productUrl = route('storefront.product', $product->slug);
    $wishlistState = app(\App\Support\StorefrontWishlistState::class);
    $wishSignedIn = $wishlistState->authenticated();
    $saved = $wishSignedIn && $wishlistState->contains((int) $product->id);
    $quickVariants = (int) $product->inventory_version === 1
        ? ($product->has_variants
            ? $catalog->eligibleVariants($product)->filter(fn ($v) => \App\Services\Inventory\StorefrontDeferredStock::availableForVariant((int) $v->id, (int) $v->stock) > 0)->values()
            : $product->variants->filter(fn ($v) => $v->is_default && $v->is_active
                && !$v->trashed() && \App\Services\Inventory\StorefrontDeferredStock::availableForVariant((int) $v->id, (int) $v->stock) > 0)->values())
        : collect();
    $canAdd = ($cartVersion ?? null) !== null && $quickVariants->isNotEmpty();
    $canCheckout = $canAdd && config('storefront.p08_checkout_test_enabled', false) === true
        && config('storefront.p03_core_test_enabled', false) === true;
?>
<article class="p07-card p34-product-card" data-reveal>
    <a href="<?php echo e($productUrl); ?>" class="p07-card-link" aria-label="View <?php echo e($product->name); ?>">
        <img src="<?php echo e($catalog->productImage($product)); ?>" alt="<?php echo e($product->name); ?>" loading="lazy" class="p07-card-image">
    </a>
    <?php if($wishSignedIn): ?>
        <form method="POST" action="<?php echo e(route('storefront.wishlist.toggle')); ?>" class="p32-card-wishlist">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <button type="submit" aria-label="<?php echo e($saved ? 'Remove ' : 'Save '); ?><?php echo e($product->name); ?> <?php echo e($saved ? 'from' : 'to'); ?> wishlist">
                <?php echo $__env->make('storefront.partials.icon', ['name'=>$saved ? 'heart-fill' : 'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </button>
        </form>
    <?php else: ?>
        <a class="p32-card-wishlist p39-guest-heart" href="<?php echo e(route('storefront.account.login')); ?>"
           aria-label="Log in or register to save <?php echo e($product->name); ?> to your wishlist" title="Log in to save to wishlist">
            <?php echo $__env->make('storefront.partials.icon', ['name'=>'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </a>
    <?php endif; ?>
    <div class="p07-card-body">
        <span class="p07-card-category"><?php echo e($product->category?->name); ?></span>
        <h3><a href="<?php echo e($productUrl); ?>"><?php echo e($product->name); ?></a></h3>
        <div class="p07-card-prices">
            <strong><?php echo e($product->has_variants ? 'From ' : ''); ?>৳<?php echo e(number_format($price)); ?></strong>
            <span class="p07-stock <?php echo e($available > 0 ? 'p07-instock' : 'p07-outstock'); ?>">
                <?php echo e($available > 0 ? 'In stock' : 'Out of stock'); ?>

            </span>
        </div>
        <div class="p19-card-actions p34-product-actions">
            <?php if($canAdd): ?>
                <form action="<?php echo e(route('storefront.cart.add')); ?>" method="POST" data-async-cart class="p19-quickform">
                    <?php echo csrf_field(); ?>
                    <?php if($product->has_variants): ?>
                        <fieldset class="p61-quick-variants">
                            <legend>Choose variation</legend>
                            <div class="p61-quick-options">
                                <?php $__currentLoopData = $quickVariants->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label><input type="radio" name="product_variant_id" value="<?php echo e($variant->id); ?>"
                                        <?php if($quickVariants->count() === 1): echo 'checked'; endif; ?> required>
                                        <span><?php echo e($variant->optionValues->map(fn ($v) => $v->label)->implode(' / ')); ?></span></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if($quickVariants->count() > 20): ?><a href="<?php echo e($productUrl); ?>">View more options</a><?php endif; ?>
                        </fieldset>
                    <?php else: ?>
                        <input type="hidden" name="product_variant_id" value="<?php echo e($quickVariants->first()->id); ?>">
                    <?php endif; ?>
                    <input type="hidden" name="quantity" value="1">
                    <input type="hidden" name="cart_version" value="<?php echo e($cartVersion); ?>">
                    <button type="submit" name="intent" value="cart" class="p19-cart-action" aria-label="Add <?php echo e($product->name); ?> to cart" title="Add to Cart">
                        <?php echo $__env->make('storefront.partials.icon', ['name'=>'cart-plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>
                    <?php if($canCheckout): ?>
                        <button type="submit" name="intent" value="checkout" class="p07-card-action p34-buy-button">Buy Now <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                    <?php else: ?>
                        <a class="p07-card-action p34-buy-button" href="<?php echo e($productUrl); ?>">View Product <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
                    <?php endif; ?>
                </form>
            <?php else: ?>
                <a class="p19-cart-action" href="<?php echo e($productUrl); ?>" aria-label="<?php echo e($product->has_variants ? 'Choose options for' : 'View'); ?> <?php echo e($product->name); ?>" title="<?php echo e($product->has_variants ? 'Choose options first' : 'View product details'); ?>">
                    <?php echo $__env->make('storefront.partials.icon', ['name'=>'cart-plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </a>
                <a class="p07-card-action p34-buy-button" href="<?php echo e($productUrl); ?>">
                    <?php echo e($product->has_variants ? 'Choose Options' : 'View Product'); ?>

                    <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</article>
<?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/partials/product-card.blade.php ENDPATH**/ ?>