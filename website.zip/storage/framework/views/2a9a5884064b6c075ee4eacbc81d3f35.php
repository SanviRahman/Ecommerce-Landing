<?php
    // Use only approved, enabled reviews chosen in this published/draft section.
    // This keeps the private preview and live homepage identical and ordered.
    $visibleReviews = collect($section['items'] ?? [])
        ->filter(static fn ($item) => $item['is_enabled'] && $item['review_id'] && $reviews->has($item['review_id']))
        ->map(static fn ($item) => $reviews[$item['review_id']])->values();
?>
<div class="sf-reviews-shell p37-review-shell p39-review-shell" data-review-carousel data-p39-review-carousel
     role="region" aria-roledescription="carousel" aria-label="Customer reviews">
    <div class="sf-grid sf-grid-reviews" data-review-track aria-live="off">
        <?php $__empty_1 = true; $__currentLoopData = $visibleReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <figure class="sf-review p37-review-card">
                <div class="p37-review-stars" aria-label="<?php echo e((int) $review->rating); ?> out of 5 stars">
                    <?php echo e(str_repeat('★', max(0, min(5, (int) $review->rating)))); ?><?php echo e(str_repeat('☆', max(0, 5 - (int) $review->rating))); ?>

                </div>
                <blockquote><?php echo e($review->review_text ?: 'Rated '.(int) $review->rating.' out of 5 stars.'); ?></blockquote>
                <figcaption class="p37-review-author">
                    <?php $photo = $review->getFirstMediaUrl('review_customer_image'); ?>
                    <?php if($photo): ?>
                        <img src="<?php echo e($photo); ?>" alt="" class="p37-review-avatar" loading="lazy" decoding="async">
                    <?php else: ?>
                        <span class="p37-review-initial" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($review->customer_name, 0, 1))); ?></span>
                    <?php endif; ?>
                    <span><strong><?php echo e($review->customer_name); ?></strong>
                        <?php if($review->location): ?><small><?php echo e($review->location); ?></small><?php endif; ?>
                    </span>
                </figcaption>
            </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php if($isPreview ?? false): ?><p>No active reviews are selected in this draft.</p><?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="sf-review-controls" data-review-controls hidden>
        <button type="button" data-review-prev aria-label="Previous review">←</button>
        <button type="button" data-review-next aria-label="Next review">→</button>
    </div>
    <div class="p39-review-dots" data-review-dots aria-label="Select customer review" hidden></div>
</div>
<?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/partials/home-reviews.blade.php ENDPATH**/ ?>