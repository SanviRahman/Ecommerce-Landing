<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('content'); ?>
    <?php
        // The web middleware normally supplies $errors. Read the flashed bag as
        // a fallback so a redirected storefront form never loses its feedback.
        $flashedProductErrors = request()->hasSession() ? request()->session()->get('errors') : null;
        $hasFlashedProductErrors = $flashedProductErrors instanceof \Illuminate\Support\ViewErrorBag
            && $flashedProductErrors->any();
        // A marker from this exact product form is flashed ONLY on validation
        // failure. Do not show a warning from unrelated cart/checkout forms.
        $rejectedProductForm = old('storefront_product_origin') === $product->slug;
    ?>
    <?php if($errors->any() || $hasFlashedProductErrors || $rejectedProductForm): ?>
        <div class="p08-error p10-product-error" role="alert" aria-live="assertive">
            <strong>We could not update your cart.</strong>
            <?php if($errors->any()): ?>
                <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            <?php elseif($hasFlashedProductErrors): ?>
                <ul><?php $__currentLoopData = $flashedProductErrors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            <?php else: ?>
                <p>We could not add this item. Review the selected variation, quantity and current cart, then try again.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <div class="p07-breadcrumb" aria-label="Breadcrumb">
        <a href="<?php echo e(route('home')); ?>">Home</a><span aria-hidden="true">/</span>
        <a href="<?php echo e(route('storefront.shop')); ?>">Shop</a><span aria-hidden="true">/</span>
        <a href="<?php echo e(route('storefront.category', $category->slug)); ?>"><?php echo e($category->name); ?></a>
        <span aria-hidden="true">/</span><span><?php echo e($product->name); ?></span>
    </div>
    <div hidden data-p53-product-tracking="<?php echo e(json_encode([
        'item_id' => (string) $product->id,
        'item_name' => $product->name,
        'price' => (float) $catalog->displayPrice($product),
        'quantity' => 1,
        'item_category' => $category->name,
        'currency' => 'BDT',
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR)); ?>"></div>
    <div class="p07-detail">
        <div class="p07-product-gallery">
            <img class="p07-main-photo" src="<?php echo e($catalog->productImage($product)); ?>" alt="<?php echo e($product->name); ?>" fetchpriority="high">
            <?php if($product->getMedia('product_gallery')->isNotEmpty()): ?>
                <div class="p07-thumbnail-row" aria-label="Product gallery">
                    <?php $__currentLoopData = $product->getMedia('product_gallery')->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" data-gallery-src="<?php echo e($galleryImage->getUrl()); ?>" data-gallery-alt="<?php echo e($product->name); ?> image <?php echo e($loop->iteration); ?>" aria-label="Show image <?php echo e($loop->iteration); ?>">
                            <img src="<?php echo e($galleryImage->getUrl()); ?>" alt="" loading="lazy">
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <section class="p07-detail-summary" aria-labelledby="p07-product-name">
            <span class="p07-eyebrow"><?php echo e($category->name); ?></span>
            <h1 id="p07-product-name"><?php echo e($product->name); ?></h1>
            <div class="p07-detail-price" id="p07-selected-price"><?php echo e($product->has_variants ? 'From ' : ''); ?>৳<?php echo e(number_format($catalog->displayPrice($product))); ?></div>


            <?php if($product->has_variants): ?>
                <div id="p07-variant-picker" data-variant-matrix="<?php echo e(json_encode($selection, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR)); ?>" data-p35-managed-product="<?php echo e((int) $product->inventory_version === 1 ? '1' : '0'); ?>">
                    <?php $__currentLoopData = $selection['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <fieldset class="p07-choice-group p61-choice-group" data-choice-group="<?php echo e($option['id']); ?>">
                            <legend><?php echo e($option['name']); ?></legend>
                            <div class="p61-choice-flex" role="group" aria-label="Choose <?php echo e($option['name']); ?>">
                                <?php $__currentLoopData = $option['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $swatch = isset($value['swatch']) && preg_match('/\A#[0-9a-fA-F]{6}\z/D', (string) $value['swatch']) ? $value['swatch'] : null; ?>
                                    <label class="p61-choice-label">
                                        <input type="radio" name="option_<?php echo e($option['id']); ?>" data-option-id="<?php echo e($option['id']); ?>"
                                            value="<?php echo e($value['id']); ?>" aria-label="<?php echo e($value['label']); ?>">
                                        <span class="p61-choice-chip">
                                            <?php if($swatch): ?><span class="p61-color-dot" style="--p61-swatch:<?php echo e($swatch); ?>" aria-hidden="true"></span><?php endif; ?>
                                            <?php echo e($value['label']); ?>

                                        </span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </fieldset>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class="p07-variant-status" id="p07-variant-status" role="status" aria-live="polite">Select all options to view exact price and stock.</p>
                    <p class="p07-sku" id="p07-variant-sku"></p>
                </div>
            <?php else: ?>
                <?php
                    $physicalStock = $catalog->physicalStock($product);
                    $sellableStock = $catalog->displayStock($product);
                ?>
                <p class="p07-variant-status" role="status">
                    <?php echo e($physicalStock > 0 ? 'Total stock: '.$physicalStock : 'Currently out of stock'); ?>

                    <?php if($physicalStock > 0 && $sellableStock === 0): ?>
                        <span>(temporarily reserved by pending orders)</span>
                    <?php endif; ?>
                </p>
                <?php if($product->weight_size): ?><p class="p07-sku"><?php echo e($product->weight_size); ?></p><?php endif; ?>
            <?php endif; ?>
            <?php if($cartVersion !== null): ?>
                <?php
                    // Cart is variant-owned. Legacy displayed stock is NOT sufficient for a safe order.
                    $simpleDefault = !$product->has_variants && (int) $product->inventory_version === 1
                        ? $product->variants()->where('is_default', true)->where('is_active', true)
                            ->where('option_signature', 'default')->where('stock', '>', 0)->first()
                        : null;
                    $canSelectSku = (int) $product->inventory_version === 1 && ($product->has_variants
                        ? $catalog->eligibleVariants($product)->contains(static fn ($v) => \App\Services\Inventory\StorefrontDeferredStock::availableForVariant((int) $v->id, (int) $v->stock) > 0)
                        : ($simpleDefault !== null && \App\Services\Inventory\StorefrontDeferredStock::availableForVariant(
                            (int) $simpleDefault->id, (int) $simpleDefault->stock) > 0));
                    $canCheckoutNow = config('storefront.p08_checkout_test_enabled', false) === true
                        && config('storefront.p03_core_test_enabled', false) === true;
                ?>
                <form id="p08-product-order-form" class="p08-product-order" data-async-cart method="POST" action="<?php echo e(route('storefront.cart.add')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="storefront_product_origin" value="<?php echo e($product->slug); ?>">
                    <input type="hidden" name="cart_version" value="<?php echo e($cartVersion); ?>">
                    <?php if($product->has_variants): ?>
                        
                        <input type="hidden" name="product_variant_id" id="p08-variant-id"
                            value="<?php echo e(old('product_variant_id', '')); ?>">
                    <?php else: ?>
                        <input type="hidden" name="product_variant_id" value="<?php echo e($simpleDefault?->id); ?>">
                    <?php endif; ?>
                    <div class="p35-quantity-field">
                        <label for="p08-product-quantity">Quantity</label>
                        <div class="p35-quantity-stepper" data-p35-quantity-stepper>
                            <button type="button" data-p35-qty-step="-1" aria-label="Decrease quantity" aria-controls="p08-product-quantity">−</button>
                            <input type="number" name="quantity" id="p08-product-quantity" min="1"
                                max="<?php echo e($simpleDefault ? min(1000, \App\Services\Inventory\StorefrontDeferredStock::availableForVariant((int) $simpleDefault->id, (int) $simpleDefault->stock)) : 1000); ?>"
                                value="<?php echo e(old('quantity', 1)); ?>" inputmode="numeric" required>
                            <button type="button" data-p35-qty-step="1" aria-label="Increase quantity" aria-controls="p08-product-quantity">+</button>
                        </div>
                    </div>
                    <div class="p08-product-actions p35-product-actions" id="p19-primary-buy-actions">
                        <button type="submit" name="intent" value="cart" class="p08-action-cart"
                            <?php if($product->has_variants): ?> data-p35-variant-required <?php endif; ?>
                            <?php if(!$canSelectSku): echo 'disabled'; endif; ?>>
                            <?php echo $__env->make('storefront.partials.icon', ['name'=>'cart-plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <span>Add to Cart</span>
                        </button>
                        <?php if($canCheckoutNow): ?>
                            <button type="submit" name="intent" value="checkout" class="p08-action-buy"
                                <?php if($product->has_variants): ?> data-p35-variant-required <?php endif; ?>
                                <?php if(!$canSelectSku): echo 'disabled'; endif; ?>>Buy Now <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                        <?php else: ?>
                            <button type="button" class="p08-action-buy" disabled aria-describedby="p35-checkout-availability"
                                title="Checkout is not yet available">Buy Now <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                        <?php endif; ?>
                    </div>
                    <p class="p08-help">Cash on delivery. Prices and availability are verified again before confirming an order.</p>
                    <?php if (! ($canSelectSku)): ?>
                        <p class="p35-purchase-note" role="status">This product is not yet available to add to the online cart. Please contact us for ordering assistance.</p>
                    <?php endif; ?>
                </form>
                <?php if (! ($canCheckoutNow)): ?>
                    <p class="p08-help p35-checkout-availability" id="p35-checkout-availability" role="status">
                        Secure checkout is temporarily unavailable. You can still review your <a href="<?php echo e(route('storefront.cart')); ?>">shopping cart</a>.
                    </p>
                <?php endif; ?>
                
                <div class="p10-mobile-buy p35-sticky-buy" data-sticky-order hidden aria-label="Quick purchase action">
                    <div class="p19-sticky-product">
                        <img src="<?php echo e($catalog->productImage($product)); ?>" alt="" loading="lazy" width="46" height="46">
                        <span><strong><?php echo e(\Illuminate\Support\Str::limit($product->name, 28)); ?></strong>
                            <small data-p35-sticky-price><?php echo e($product->has_variants ? 'From ' : ''); ?>৳<?php echo e(number_format($catalog->displayPrice($product))); ?></small></span>
                    </div>
                    <?php if($canCheckoutNow): ?>
                        <button form="p08-product-order-form" type="submit" name="intent" value="checkout"
                            <?php if($product->has_variants): ?> data-p35-variant-required <?php endif; ?>
                            <?php if(!$canSelectSku): echo 'disabled'; endif; ?>>Buy Now <?php echo $__env->make('storefront.partials.icon', ['name'=>'arrow-right'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                    <?php else: ?>
                        <button type="button" disabled title="Checkout is temporarily unavailable">Buy Now</button>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="p07-checkout-notice" role="note">
                    <strong>Product information</strong>
                    <span>Online ordering is unavailable for this server. Please contact us for assistance.</span>
                </div>
            <?php endif; ?>
            <?php
                $wishlistState = app(\App\Support\StorefrontWishlistState::class);
                $wishSignedIn = $wishlistState->authenticated();
                $isSaved = $wishSignedIn && $wishlistState->contains((int) $product->id);
            ?>
            <div class="p32-wishlist-form">
                <?php if($wishSignedIn): ?>
                    <form method="POST" action="<?php echo e(route('storefront.wishlist.toggle')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <button type="submit" class="p32-wishlist-btn" aria-label="<?php echo e($isSaved ? 'Remove from' : 'Add to'); ?> wishlist">
                            <?php echo $__env->make('storefront.partials.icon', ['name'=>$isSaved ? 'heart-fill' : 'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php echo e($isSaved ? 'Saved to Wishlist' : 'Save to Wishlist'); ?>

                        </button>
                    </form>
                    <a href="<?php echo e(route('storefront.wishlist')); ?>" class="p32-wishlist-view">View Wishlist</a>
                <?php else: ?>
                    <a href="<?php echo e(route('storefront.account.login')); ?>" class="p32-wishlist-btn p39-login-wishlist"
                       aria-label="Log in or register to save this product">
                        <?php echo $__env->make('storefront.partials.icon', ['name'=>'heart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Sign in to Save
                    </a>
                    <a href="<?php echo e(route('storefront.account.register')); ?>" class="p32-wishlist-view">Create account</a>
                <?php endif; ?>
            </div>
            <a class="p07-back-to-shop" href="<?php echo e(route('storefront.shop')); ?>">Explore more products</a>
        </section>
    </div>

    <?php if($product->short_description): ?>
        <section class="p19-product-benefits" aria-label="Product highlights"><h2>Product highlights</h2><p><?php echo e($product->short_description); ?></p></section>
    <?php endif; ?>
    <?php if($product->full_description): ?>
        <section class="p07-description" aria-labelledby="p07-description-heading">
            <h2 id="p07-description-heading">Product description</h2>
            <div class="p07-description-body"><?php echo e($product->full_description); ?></div>
        </section>
    <?php endif; ?>
    <?php if(($relatedProducts ?? collect())->isNotEmpty()): ?>
        <section class="p35-related-products" aria-labelledby="p35-related-heading" data-reveal>
            <div class="p35-related-heading">
                <div><span class="p07-eyebrow">DISCOVER MORE</span><h2 id="p35-related-heading">Related products</h2>
                    <p>More items from our active collections.</p></div>
                <a href="<?php echo e(route('storefront.shop')); ?>">Explore all products →</a>
            </div>
            <div class="p07-card-grid p35-related-grid" data-reveal-stagger>
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('storefront.partials.product-card', ['product' => $relatedProduct], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('storefront.layouts.catalog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Ecommerce-Landing\website\resources\views/storefront/pages/product.blade.php ENDPATH**/ ?>