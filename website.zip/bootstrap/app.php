<?php

require_once __DIR__ . '/runtime.php';

use App\Http\Middleware\LogRequestLifecycle;
use App\Http\Middleware\LteContext;
use App\Http\Middleware\RoleMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Keep a lightweight audit trail for every HTTP feature execution.
        // It only observes requests; it does not change route/controller logic.
        $middleware->prepend(LogRequestLifecycle::class);

        $middleware->alias([
            'lte_context' => LteContext::class,
            'role'        => RoleMiddleware::class,
        ]);

        $middleware->validateCsrfTokens(except: [
            'webhooks/steadfast/*',
            'webhooks/pathao/*',
        ]);

        $middleware->redirectGuestsTo('/admin/login');
        $middleware->redirectUsersTo('/admin');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();